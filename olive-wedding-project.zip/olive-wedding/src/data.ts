import { createClient } from "@supabase/supabase-js";
import { connections, wedding } from "./config";
export interface Note {
  id: string;
  author: string;
  content: string;
  color_index: number;
  created_at: string;
}
export interface Submission {
  name: string;
  phone: string;
  side: "groom" | "bride";
  attendance: boolean;
  guest_count: number;
  companions: string;
  meal_preference: "yes" | "no" | "undecided";
  message: string;
}
export const db =
  connections.supabaseUrl && connections.supabaseKey
    ? createClient(connections.supabaseUrl, connections.supabaseKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      })
    : null;
export const localMode = !db;
export const storageKey = `wedding:${wedding.id}`;
export const uid = () =>
  globalThis.crypto?.randomUUID?.() ||
  "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.floor(Math.random() * 16);
    return (c === "x" ? r : (r & 3) | 8).toString(16);
  });
export const todayKST = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Seoul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
export function readLocal<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`${storageKey}:${key}`);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
export function writeLocal(key: string, value: unknown) {
  try {
    localStorage.setItem(`${storageKey}:${key}`, JSON.stringify(value));
  } catch {
    throw new Error(
      "브라우저 저장 공간을 사용할 수 없습니다. 저장 허용 설정을 확인해 주세요.",
    );
  }
}
export const seedNotes: Note[] = [
  {
    id: "sample-1",
    author: "지민",
    content:
      "서로의 가장 좋은 친구가 되어 줄 두 사람. 결혼 정말 축하해! 오래오래 행복하자 ♡",
    color_index: 0,
    created_at: "2026-10-01T10:00:00Z",
  },
  {
    id: "sample-2",
    author: "민수",
    content:
      "도윤아, 서연님! 두 분의 새로운 시작을 응원합니다. 결혼식에서 만나요!",
    color_index: 1,
    created_at: "2026-10-01T09:00:00Z",
  },
  {
    id: "sample-3",
    author: "수빈",
    content:
      "함께여서 더 예쁜 두 사람. 오늘의 설렘이 매일의 다정함으로 이어지길 ♡",
    color_index: 2,
    created_at: "2026-10-01T08:00:00Z",
  },
  {
    id: "sample-4",
    author: "현우",
    content: "가장 빛나는 날, 기쁜 마음으로 함께할게요. 축하합니다!",
    color_index: 3,
    created_at: "2026-10-01T07:00:00Z",
  },
];
export function localNotes(): Note[] {
  const value = readLocal<unknown>("notes", seedNotes);
  return Array.isArray(value)
    ? value.filter(
        (n) =>
          n &&
          typeof n.id === "string" &&
          typeof n.author === "string" &&
          typeof n.content === "string" &&
          Number.isInteger(n.color_index) &&
          n.color_index >= 0 &&
          n.color_index <= 5,
      )
    : seedNotes;
}
export async function loadNotes(): Promise<Note[]> {
  if (!db) return localNotes();
  const { data, error } = await db
    .from("guestbook_messages")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) throw error;
  return data || [];
}
export async function saveNote(author: string, content: string): Promise<Note> {
  const note: Note = {
    id: uid(),
    author: author.trim(),
    content: content.trim(),
    color_index: Math.floor(Math.random() * 6),
    created_at: new Date().toISOString(),
  };
  if (!db) {
    writeLocal("notes", [note, ...localNotes()].slice(0, 200));
    return note;
  }
  const { data, error } = await db
    .from("guestbook_messages")
    .insert(note)
    .select()
    .single();
  if (error) throw error;
  return data;
}
export async function saveSubmission(value: Submission, id: string) {
  if (!db) {
    const rows = readLocal<unknown>("rsvp", []);
    writeLocal("rsvp", [
      ...(Array.isArray(rows) ? rows : []),
      { ...value, id, created_at: new Date().toISOString() },
    ]);
    return;
  }
  const { error } = await db.from("rsvp_submissions").insert({ ...value, id });
  if (error && error.code !== "23505") throw error;
}
