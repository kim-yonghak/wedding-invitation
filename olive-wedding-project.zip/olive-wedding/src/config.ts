import hero from "./assets/hero.jpg";
import gallery1 from "./assets/gallery-1.jpg";
import gallery2 from "./assets/gallery-2.jpg";
import gallery3 from "./assets/gallery-3.jpg";
import guide1 from "./assets/guide-1.jpg";
import guide2 from "./assets/guide-2.jpg";
import guide3 from "./assets/guide-3.jpg";

// 실제 청첩장 정보는 여기서 수정하세요. 사진은 src/assets의 같은 이름 파일을 교체합니다.
export const wedding = {
  demo: true,
  id: "doyun-seoyeon-20270522",
  monogram: ["D", "S"],
  englishNames: "DOYUN & SEOYEON",
  groom: {
    name: "김도윤",
    firstName: "도윤",
    father: "김정호",
    mother: "박미영",
  },
  bride: {
    name: "이서연",
    firstName: "서연",
    father: "이상훈",
    mother: "최은정",
  },
  date: "2027-05-22T14:00:00+09:00",
  venue: "올리브 가든",
  hall: "2층 가든홀",
  address: "서울특별시 성동구 · 상세 주소 입력 예정",
  mapQuery: "서울숲", // 테스트용 지도 검색어. 실제 주소로 교체하세요.
  map: { latitude: 37.5445, longitude: 127.0374 }, // 예시 좌표. 실제 예식장 좌표로 교체하세요.
  transit: "가든역 2번 출구에서 도보 5분",
  bus: "가든웨딩홀 정류장 하차 · 도보 2분",
  parking: "예식장 지하 1–3층 · 하객 2시간 무료 주차",
  hero,
  gallery: [
    {
      src: gallery1,
      alt: "정원에서 이마를 맞대고 웃는 두 사람",
      caption: "너와 나, 가장 가까운 계절",
    },
    {
      src: gallery2,
      alt: "부케 곁에서 꼭 맞잡은 두 손",
      caption: "앞으로의 모든 날에도",
    },
    {
      src: gallery3,
      alt: "올리브 나무 사이를 함께 걷는 두 사람",
      caption: "같은 방향으로, 함께",
    },
  ],
  guides: [
    {
      image: guide1,
      title: "우리의 약속이 시작되는 곳",
      tag: "CEREMONY",
      text: "2층 가든홀에서 예식이 진행됩니다. 시작 20분 전까지 도착하시면 여유롭게 인사 나누실 수 있습니다.",
    },
    {
      image: guide2,
      title: "따뜻한 식사를 준비했어요",
      tag: "DINING",
      text: "예식 전후로 1층 연회장에서 식사하실 수 있습니다. 식권은 양가 접수대에서 받아 주세요.",
    },
    {
      image: guide3,
      title: "편안한 걸음으로 오세요",
      tag: "WELCOME",
      text: "주차 후 중앙 엘리베이터를 이용해 주세요. 유아 동반 및 이동에 도움이 필요한 하객은 안내 데스크로 문의해 주세요.",
    },
  ],
  contacts: [
    [
      { relation: "신랑", name: "김도윤", phone: "010-0000-0000" },
      { relation: "신랑 아버지", name: "김정호", phone: "010-0000-0000" },
      { relation: "신랑 어머니", name: "박미영", phone: "010-0000-0000" },
    ],
    [
      { relation: "신부", name: "이서연", phone: "010-0000-0000" },
      { relation: "신부 아버지", name: "이상훈", phone: "010-0000-0000" },
      { relation: "신부 어머니", name: "최은정", phone: "010-0000-0000" },
    ],
  ],
  accounts: [
    [
      {
        relation: "신랑",
        name: "김도윤",
        bank: "국민은행",
        number: "000000-00-000000",
      },
      {
        relation: "아버지",
        name: "김정호",
        bank: "신한은행",
        number: "000-000-000000",
      },
      {
        relation: "어머니",
        name: "박미영",
        bank: "우리은행",
        number: "0000-000-000000",
      },
    ],
    [
      {
        relation: "신부",
        name: "이서연",
        bank: "카카오뱅크",
        number: "0000-00-0000000",
      },
      {
        relation: "아버지",
        name: "이상훈",
        bank: "하나은행",
        number: "000-000000-00000",
      },
      {
        relation: "어머니",
        name: "최은정",
        bank: "농협은행",
        number: "000-0000-0000-00",
      },
    ],
  ],
};

export const connections = {
  supabaseUrl: import.meta.env.VITE_SUPABASE_URL || "",
  supabaseKey:
    import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
    import.meta.env.VITE_SUPABASE_ANON_KEY ||
    "",
  kakaoKey: import.meta.env.VITE_KAKAO_JAVASCRIPT_KEY || "",
  siteUrl: import.meta.env.VITE_SITE_URL || "",
  shareImageUrl: import.meta.env.VITE_SHARE_IMAGE_URL || "",
};
