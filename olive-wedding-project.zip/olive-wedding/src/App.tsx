import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  Copy,
  Heart,
  MapPin,
  MessageCircle,
  Navigation,
  Phone,
  Send,
  Sparkles,
  TrainFront,
  CarFront,
  BusFront,
  PenLine,
  X,
} from "lucide-react";
import { Button } from "./components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "./components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./components/ui/accordion";
import { wedding as w, connections } from "./config";
import {
  db,
  localMode,
  loadNotes,
  saveNote,
  saveSubmission,
  storageKey,
  uid,
  type Note,
  type Submission,
} from "./data";

declare global {
  interface Window {
    Kakao?: any;
    kakao?: any;
  }
}
const eventDate = new Date(w.date);
const kstParts = Object.fromEntries(
  new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Seoul",
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    hour12: false,
  })
    .formatToParts(eventDate)
    .map((p) => [p.type, p.value]),
);
const year = +kstParts.year,
  month = +kstParts.month,
  day = +kstParts.day;
const dateLine = new Intl.DateTimeFormat("ko-KR", {
  timeZone: "Asia/Seoul",
  year: "numeric",
  month: "long",
  day: "numeric",
  weekday: "long",
}).format(eventDate);
const timeLine = new Intl.DateTimeFormat("ko-KR", {
  timeZone: "Asia/Seoul",
  hour: "numeric",
  minute: "2-digit",
}).format(eventDate);
const weekdayEnglish = new Intl.DateTimeFormat("en-US", {
  timeZone: "Asia/Seoul",
  weekday: "long",
})
  .format(eventDate)
  .toUpperCase();
const pad = (v: number) => String(v).padStart(2, "0");
const sampleMapQuery = encodeURIComponent(w.mapQuery);
const maps = {
  naver: `https://map.naver.com/p/search/${sampleMapQuery}`,
  kakao: `https://map.kakao.com/link/search/${sampleMapQuery}`,
};
const startForm: Submission = {
  name: "",
  phone: "",
  side: "groom",
  attendance: true,
  guest_count: 1,
  companions: "",
  meal_preference: "undecided",
  message: "",
};

function Star({ className = "" }: { className?: string }) {
  return (
    <span className={`star ${className}`} aria-hidden="true">
      ✦
    </span>
  );
}
function Divider() {
  return (
    <div className="divider" aria-hidden="true">
      <span />
      <Star />
      <span />
    </div>
  );
}
function Title({ label, children }: { label: string; children: ReactNode }) {
  return (
    <header className="section-title">
      <span className="eyebrow">{label}</span>
      <h2>{children}</h2>
    </header>
  );
}
function Reveal({
  children,
  className = "",
  id,
}: {
  children: ReactNode;
  className?: string;
  id?: string;
}) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          el.classList.add("is-visible");
          observer.disconnect();
        }
      },
      { threshold: 0.06 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return (
    <section ref={ref} id={id} className={`section reveal ${className}`}>
      {children}
    </section>
  );
}
function Choice({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <fieldset className="choice-field">
      <legend>{label}</legend>
      <div className="choice-options">
        {options.map((opt) => (
          <label
            className={`choice ${value === opt.value ? "selected" : ""}`}
            key={opt.value}
          >
            <input
              type="radio"
              name={label}
              value={opt.value}
              checked={value === opt.value}
              onChange={() => onChange(opt.value)}
            />
            <span>{opt.label}</span>
            {value === opt.value && <Check size={14} />}
          </label>
        ))}
      </div>
    </fieldset>
  );
}
function Calendar() {
  const first = new Date(Date.UTC(year, month - 1, 1)).getUTCDay(),
    days = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return (
    <div
      className="calendar"
      aria-label={`${year}년 ${month}월 달력, ${day}일 결혼식`}
    >
      <div className="calendar-heading">
        <span>{year}</span>
        <strong>
          {pad(month)} <Star />
        </strong>
        <span>
          {new Intl.DateTimeFormat("en-US", {
            month: "long",
            timeZone: "Asia/Seoul",
          })
            .format(eventDate)
            .toUpperCase()}
        </span>
      </div>
      <div className="calendar-grid">
        {["일", "월", "화", "수", "목", "금", "토"].map((d, i) => (
          <span className={`weekday ${i === 0 ? "sunday" : ""}`} key={d}>
            {d}
          </span>
        ))}
        {Array.from({ length: first }, (_, i) => (
          <span key={`blank-${i}`} />
        ))}
        {Array.from({ length: days }, (_, i) => (
          <span
            key={i}
            className={`calendar-day ${(i + first) % 7 === 0 ? "sunday" : ""} ${i + 1 === day ? "wedding-day" : ""}`}
            aria-label={
              i + 1 === day ? `${month}월 ${day}일 결혼식` : undefined
            }
          >
            {i + 1 === day ? (
              <>
                <Heart size={38} fill="currentColor" strokeWidth={1} />
                <b>{i + 1}</b>
              </>
            ) : (
              i + 1
            )}
          </span>
        ))}
      </div>
    </div>
  );
}
function Countdown() {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = eventDate.getTime() - now,
    total = Math.max(0, Math.floor(diff / 1000));
  const values = [
    Math.floor(total / 86400),
    Math.floor(total / 3600) % 24,
    Math.floor(total / 60) % 60,
    total % 60,
  ];
  const eventDay = Math.floor((eventDate.getTime() + 9 * 3600000) / 86400000),
    nowDay = Math.floor((now + 9 * 3600000) / 86400000),
    d = eventDay - nowDay;
  return (
    <>
      <div
        className="countdown"
        aria-label={`예식까지 ${values[0]}일 ${values[1]}시간 ${values[2]}분 ${values[3]}초`}
      >
        {values.map((v, i) => (
          <div key={i}>
            <strong>{pad(v)}</strong>
            <span>{["DAYS", "HOURS", "MINUTES", "SECONDS"][i]}</span>
          </div>
        ))}
      </div>
      <p className="d-day">
        {w.groom.firstName} <Heart size={13} fill="currentColor" />{" "}
        {w.bride.firstName}의 결혼식
        {d > 0 ? (
          <>
            이 <b>{d}일</b> 남았습니다
          </>
        ) : d === 0 ? (
          <>
            이 <b>오늘</b>입니다
          </>
        ) : (
          <>에 함께해 주셔서 감사합니다</>
        )}
      </p>
    </>
  );
}
function DemoMap() {
  return (
    <svg
      className="demo-map"
      viewBox="0 0 420 265"
      role="img"
      aria-label="올리브 가든 테스트용 약도. 실제 위치와 다릅니다."
    >
      <rect width="420" height="265" fill="#e9e9dc" />
      <path
        d="M0 55H420M0 198H420M88 0V265M328 0V265"
        stroke="#fafaf2"
        strokeWidth="27"
      />
      <path
        d="M0 55H420M0 198H420M88 0V265M328 0V265"
        stroke="#cdcfbb"
        strokeWidth="1"
        strokeDasharray="4 5"
      />
      <rect x="121" y="85" width="160" height="85" rx="13" fill="#c3cc9a" />
      <rect x="10" y="92" width="50" height="75" rx="6" fill="#d7dbbd" />
      <rect x="355" y="84" width="49" height="90" rx="6" fill="#d7dbbd" />
      <g fill="#adb98a">
        <circle cx="138" cy="110" r="8" />
        <circle cx="258" cy="112" r="8" />
        <circle cx="138" cy="148" r="8" />
        <circle cx="258" cy="148" r="8" />
      </g>
      <path
        d="M192 104a14 14 0 1 1 28 0c0 12-14 22-14 22s-14-10-14-22"
        fill="#474a37"
      />
      <circle cx="206" cy="104" r="5" fill="#d8e592" />
      <text
        x="206"
        y="150"
        textAnchor="middle"
        fill="#343a29"
        fontSize="14"
        fontFamily="Noto Sans KR"
      >
        올리브 가든
      </text>
      <rect x="50" y="185" width="76" height="26" rx="13" fill="#858d64" />
      <text
        x="88"
        y="203"
        textAnchor="middle"
        fill="white"
        fontSize="11"
        fontFamily="Noto Sans KR"
      >
        가든역
      </text>
      <text
        x="205"
        y="237"
        textAnchor="middle"
        fill="#777c66"
        fontSize="11"
        fontFamily="Noto Sans KR"
      >
        테스트 약도 · 실제 위치와 다릅니다
      </text>
    </svg>
  );
}
function MapPanel() {
  const ref = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (w.demo || !connections.kakaoKey) return;
    const script = document.createElement("script");
    script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${encodeURIComponent(connections.kakaoKey)}&autoload=false`;
    script.onload = () =>
      window.kakao?.maps.load(() => {
        if (!ref.current) return;
        const pos = new window.kakao.maps.LatLng(
          w.map.latitude,
          w.map.longitude,
        );
        const map = new window.kakao.maps.Map(ref.current, {
          center: pos,
          level: 3,
        });
        new window.kakao.maps.Marker({ position: pos, map });
        setReady(true);
      });
    document.head.append(script);
    return () => {
      script.remove();
    };
  }, []);
  return (
    <div className="map-wrap">
      <div
        ref={ref}
        className={`live-map ${ready ? "ready" : ""}`}
        aria-label="예식장 카카오 지도"
      />
      {!ready && <DemoMap />}
    </div>
  );
}

export default function App() {
  const [contactOpen, setContactOpen] = useState(false),
    [rsvpOpen, setRsvpOpen] = useState(false),
    [noteOpen, setNoteOpen] = useState(false);
  const [photo, setPhoto] = useState<number | null>(null),
    [galleryIndex, setGalleryIndex] = useState(0);
  const [toast, setToast] = useState(""),
    toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [form, setForm] = useState<Submission>({ ...startForm }),
    [formError, setFormError] = useState(""),
    [sending, setSending] = useState(false),
    [sent, setSent] = useState(false);
  const [noteName, setNoteName] = useState(""),
    [noteContent, setNoteContent] = useState(""),
    [noteError, setNoteError] = useState(""),
    [noteSaving, setNoteSaving] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]),
    [loadError, setLoadError] = useState(""),
    [realtimeState, setRealtimeState] = useState(
      localMode ? "테스트 메시지" : "연결 중",
    );
  const galleryRef = useRef<HTMLDivElement>(null),
    submissionId = useRef(uid()),
    submissionGuard = useRef(false),
    noteGuard = useRef(false);
  function notify(text: string) {
    setToast(text);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 3800);
  }
  useEffect(
    () => () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    },
    [],
  );
  useEffect(() => {
    let active = true;
    const reload = () =>
      loadNotes()
        .then((n) => {
          if (active) {
            setNotes((prev) =>
              db
                ? [
                    ...new Map([...n, ...prev].map((x) => [x.id, x])).values(),
                  ].sort((a, b) => b.created_at.localeCompare(a.created_at))
                : n,
            );
            setLoadError("");
          }
        })
        .catch(() => {
          if (active)
            setLoadError(
              "메시지를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요.",
            );
        });
    reload();
    const onStorage = (e: StorageEvent) => {
      if (e.key === `${storageKey}:notes`) reload();
    };
    window.addEventListener("storage", onStorage);
    const channel = db
      ?.channel(`guestbook-${w.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "guestbook_messages" },
        (payload) => {
          const note = payload.new as Note;
          setNotes((prev) =>
            prev.some((n) => n.id === note.id)
              ? prev
              : [note, ...prev].slice(0, 200),
          );
        },
      )
      .subscribe((status) => {
        if (!active) return;
        setRealtimeState(
          status === "SUBSCRIBED"
            ? "실시간 연결"
            : status === "CHANNEL_ERROR" || status === "TIMED_OUT"
              ? "연결 확인 중"
              : "연결 중",
        );
        if (status === "SUBSCRIBED") reload();
      });
    return () => {
      active = false;
      window.removeEventListener("storage", onStorage);
      if (channel) db?.removeChannel(channel);
    };
  }, []);
  useEffect(() => {
    if (!connections.kakaoKey) return;
    const script = document.createElement("script");
    script.src = "https://t1.kakaocdn.net/kakao_js_sdk/2.8.3/kakao.min.js";
    script.onload = () => {
      if (window.Kakao && !window.Kakao.isInitialized())
        window.Kakao.init(connections.kakaoKey);
    };
    document.head.append(script);
    return () => script.remove();
  }, []);
  useEffect(() => {
    if (photo === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight")
        setPhoto((v) => (v === null ? null : (v + 1) % w.gallery.length));
      if (e.key === "ArrowLeft")
        setPhoto((v) =>
          v === null ? null : (v + w.gallery.length - 1) % w.gallery.length,
        );
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [photo]);
  async function copy(text: string, success = "복사했습니다") {
    try {
      if (navigator.clipboard && window.isSecureContext)
        await navigator.clipboard.writeText(text);
      else {
        const input = document.createElement("textarea");
        input.value = text;
        input.style.position = "fixed";
        input.style.opacity = "0";
        document.body.append(input);
        input.select();
        const ok = document.execCommand("copy");
        input.remove();
        if (!ok) throw new Error();
      }
      notify(success);
    } catch {
      notify("복사할 수 없습니다. 텍스트를 길게 눌러 복사해 주세요.");
    }
  }
  function shareUrl() {
    return (
      connections.siteUrl ||
      (/^https?:$/.test(location.protocol) ? location.href.split("#")[0] : "")
    );
  }
  async function share() {
    const url = shareUrl();
    if (!url) {
      notify("테스트 파일입니다. 웹에 배포한 후 공유할 수 있어요.");
      return;
    }
    try {
      if (window.Kakao?.isInitialized() && connections.shareImageUrl) {
        window.Kakao.Share.sendDefault({
          objectType: "feed",
          content: {
            title: `${w.groom.firstName} & ${w.bride.firstName}의 결혼식`,
            description: `${dateLine} ${timeLine} · ${w.venue}`,
            imageUrl: connections.shareImageUrl,
            link: { mobileWebUrl: url, webUrl: url },
          },
          buttons: [
            { title: "청첩장 보기", link: { mobileWebUrl: url, webUrl: url } },
          ],
        });
      } else if (navigator.share) {
        await navigator.share({
          title: `${w.groom.firstName} & ${w.bride.firstName}의 결혼식`,
          text: `${dateLine} ${timeLine}`,
          url,
        });
      } else {
        await copy(url, "링크를 복사했어요. 카카오톡에 붙여넣어 주세요.");
      }
    } catch (e) {
      if ((e as Error).name !== "AbortError")
        notify("공유를 열지 못했습니다. 링크 복사를 이용해 주세요.");
    }
  }
  function selectGallery(index: number) {
    galleryRef.current?.children[index]?.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "center",
    });
    setGalleryIndex(index);
  }
  function trackGallery() {
    const track = galleryRef.current;
    if (!track) return;
    const center = track.getBoundingClientRect().left + track.clientWidth / 2;
    let closest = 0,
      dist = Infinity;
    Array.from(track.children).forEach((node, i) => {
      const rect = node.getBoundingClientRect(),
        d = Math.abs(rect.left + rect.width / 2 - center);
      if (d < dist) {
        closest = i;
        dist = d;
      }
    });
    setGalleryIndex(closest);
  }
  async function submitRsvp(e: FormEvent) {
    e.preventDefault();
    if (submissionGuard.current) return;
    setFormError("");
    if (!form.name.trim()) {
      setFormError("성함을 입력해 주세요.");
      return;
    }
    if (form.phone && !/^[0-9+()\s-]{8,20}$/.test(form.phone)) {
      setFormError("연락처 형식을 확인해 주세요.");
      return;
    }
    if (
      form.attendance &&
      (!Number.isInteger(form.guest_count) ||
        form.guest_count < 1 ||
        form.guest_count > 30)
    ) {
      setFormError("참석 인원을 1–30명 사이로 입력해 주세요.");
      return;
    }
    submissionGuard.current = true;
    setSending(true);
    try {
      await saveSubmission(
        {
          ...form,
          name: form.name.trim(),
          phone: form.phone.trim(),
          guest_count: form.attendance ? form.guest_count : 0,
          companions: form.attendance ? form.companions.trim() : "",
          meal_preference: form.attendance ? form.meal_preference : "no",
          message: form.message.trim(),
        },
        submissionId.current,
      );
      setSent(true);
    } catch (e) {
      setFormError(
        localMode
          ? (e as Error).message
          : "전달하지 못했습니다. 네트워크 연결을 확인하고 다시 시도해 주세요.",
      );
    } finally {
      setSending(false);
      submissionGuard.current = false;
    }
  }
  async function submitNote(e: FormEvent) {
    e.preventDefault();
    if (noteGuard.current) return;
    setNoteError("");
    if (!noteName.trim() || !noteContent.trim()) {
      setNoteError("이름과 축하 메시지를 모두 입력해 주세요.");
      return;
    }
    noteGuard.current = true;
    setNoteSaving(true);
    try {
      const note = await saveNote(noteName, noteContent);
      setNotes((prev) =>
        prev.some((n) => n.id === note.id)
          ? prev
          : [note, ...prev].slice(0, 200),
      );
      setNoteOpen(false);
      setNoteName("");
      setNoteContent("");
      notify(
        localMode
          ? "이 브라우저에 테스트 메시지를 저장했어요."
          : "따뜻한 마음을 남겨 주셔서 감사합니다.",
      );
    } catch (e) {
      setNoteError(
        localMode
          ? (e as Error).message
          : "메시지를 저장하지 못했습니다. 다시 시도해 주세요.",
      );
    } finally {
      setNoteSaving(false);
      noteGuard.current = false;
    }
  }
  return (
    <>
      <main className="invitation">
        <section className="hero" aria-label="청첩장 표지">
          <img
            className="hero-image"
            src={w.hero}
            alt="올리브 정원을 함께 걷는 신랑 신부의 웨딩 사진"
            fetchPriority="high"
          />
          <div className="hero-shade" />
          <div className="hero-top">
            <span>
              {w.monogram[0]} <Star /> {w.monogram[1]}
            </span>
            {w.demo && <span className="demo-badge">TEST INVITATION</span>}
          </div>
          <div className="hero-title">
            <p className="eyebrow">THE WEDDING OF {w.englishNames}</p>
            <h1>
              우리의 다음,
              <br />
              <em>함께.</em>
            </h1>
            <Star className="hero-star" />
          </div>
          <div className="hero-bottom">
            <p className="hero-names">
              {w.groom.name}
              <span>&</span>
              {w.bride.name}
            </p>
            <div className="hero-date">
              {year}. {pad(month)}. {pad(day)}
              <span>
                {weekdayEnglish} · {timeLine}
              </span>
            </div>
            <p className="hero-venue">
              {w.venue} · {w.hall}
            </p>
            <a
              className="scroll-hint"
              href="#invitation"
              aria-label="초대글로 이동"
            >
              <span>SCROLL TO OUR STORY</span>
              <ArrowDown size={19} />
            </a>
          </div>
        </section>
        <Divider />
        <Reveal id="invitation" className="invite-section">
          <Title label="YOU ARE INVITED">소중한 당신을 초대합니다</Title>
          <div className="invitation-symbol" aria-hidden="true">
            <span>together</span>
            <Star />
          </div>
          <div className="invitation-copy">
            <p>
              오랜 시간 곁을 지키며
              <br />
              서로의 하루가 되어주었습니다.
            </p>
            <p>
              이제 부부라는 이름으로
              <br />
              같은 방향을 걸어가려 합니다.
            </p>
            <p>
              이 뜻깊은 시작의 자리에
              <br />
              소중한 분들을 정중히 초대합니다.
            </p>
          </div>
          <div className="family-lines">
            <p>
              {w.groom.father} · {w.groom.mother}
              <span>의 장남</span>
              <strong>{w.groom.firstName}</strong>
            </p>
            <p>
              {w.bride.father} · {w.bride.mother}
              <span>의 장녀</span>
              <strong>{w.bride.firstName}</strong>
            </p>
          </div>
          <p className="signature">
            {w.groom.name} · {w.bride.name} 드림
          </p>
        </Reveal>
        <Divider />
        <Reveal className="contact-section">
          <p className="soft-copy">축복의 마음, 반가운 목소리로 전해 주세요.</p>
          <Button variant="outline" onClick={() => setContactOpen(true)}>
            <Phone size={16} />
            연락하기
            <ArrowRight size={16} />
          </Button>
        </Reveal>
        <Divider />
        <Reveal id="gallery" className="gallery-section">
          <Title label="OUR MOMENTS">함께 쌓아온 순간들</Title>
          <p className="section-intro">평범한 날들이, 너와 함께 특별해졌어.</p>
          <div
            className="gallery-track"
            ref={galleryRef}
            onScroll={trackGallery}
            aria-label="웨딩 사진 갤러리"
          >
            {w.gallery.map((item, i) => (
              <button
                type="button"
                className="gallery-slide"
                key={item.src}
                onClick={() => setPhoto(i)}
                aria-label={`사진 ${i + 1} 확대: ${item.alt}`}
              >
                <img src={item.src} alt={item.alt} loading="lazy" />
                <span className="photo-expand">+ 크게 보기</span>
              </button>
            ))}
          </div>
          <div className="gallery-controls">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => selectGallery(Math.max(0, galleryIndex - 1))}
              disabled={galleryIndex === 0}
              aria-label="이전 사진"
            >
              <ArrowLeft size={18} />
            </Button>
            <div className="gallery-dots">
              {w.gallery.map((_, i) => (
                <button
                  key={i}
                  onClick={() => selectGallery(i)}
                  aria-label={`${i + 1}번째 사진`}
                  aria-current={galleryIndex === i ? "true" : undefined}
                >
                  <span />
                </button>
              ))}
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() =>
                selectGallery(Math.min(w.gallery.length - 1, galleryIndex + 1))
              }
              disabled={galleryIndex === w.gallery.length - 1}
              aria-label="다음 사진"
            >
              <ArrowRight size={18} />
            </Button>
          </div>
          <p className="photo-caption">{w.gallery[galleryIndex].caption}</p>
        </Reveal>
        <Divider />
        <Reveal id="date">
          <Title label="SAVE THE DATE">우리, 결혼합니다</Title>
          <p className="wedding-date-line">
            {dateLine}
            <br />
            {timeLine}
          </p>
          <Calendar />
          <Countdown />
        </Reveal>
        <Divider />
        <Reveal id="location">
          <Title label="HOW TO GET HERE">만나는 곳</Title>
          <div className="venue-heading">
            <h3>{w.venue}</h3>
            <p>{w.hall}</p>
            <p className="address">{w.address}</p>
            <button
              className="text-button"
              onClick={() => copy(w.address, "주소를 복사했어요.")}
            >
              <Copy size={13} />
              주소 복사
            </button>
          </div>
          <MapPanel />
          <div className="map-buttons">
            <Button asChild variant="outline">
              <a href={maps.naver} target="_blank" rel="noopener noreferrer">
                <span className="naver-mark">N</span>네이버 지도
              </a>
            </Button>
            <Button asChild variant="outline">
              <a href={maps.kakao} target="_blank" rel="noopener noreferrer">
                <MapPin size={16} />
                카카오 지도
              </a>
            </Button>
          </div>
          <Button asChild className="full">
            <a href={maps.kakao} target="_blank" rel="noopener noreferrer">
              <Navigation size={16} />
              길찾기
              <ArrowRight size={17} />
            </a>
          </Button>
          {w.demo && (
            <p className="helper">
              예시 장소입니다. 지도 링크는 서울숲 검색으로 연결됩니다.
            </p>
          )}
          <div className="transport">
            <article>
              <TrainFront size={19} />
              <div>
                <h4>지하철</h4>
                <p>{w.transit}</p>
              </div>
            </article>
            <article>
              <BusFront size={19} />
              <div>
                <h4>버스</h4>
                <p>{w.bus}</p>
              </div>
            </article>
            <article>
              <CarFront size={19} />
              <div>
                <h4>주차 안내</h4>
                <p>{w.parking}</p>
                <p>혼잡할 수 있으니 여유 있게 출발해 주세요.</p>
              </div>
            </article>
          </div>
        </Reveal>
        <Divider />
        <Reveal id="guide">
          <Title label="FOR OUR GUESTS">편안한 하루를 위해</Title>
          <p className="section-intro">함께해 주실 소중한 분들께 전하는 안내</p>
          <div className="guide-cards">
            {w.guides.map((guide, i) => (
              <article className="guide-card" key={guide.title}>
                <img
                  src={guide.image}
                  alt={guide.title + " · AI 생성 예시 사진"}
                  loading="lazy"
                />
                <div className="guide-content">
                  <span className="guide-index">0{i + 1}</span>
                  <span className="eyebrow">{guide.tag}</span>
                  <h3>{guide.title}</h3>
                  <p>{guide.text}</p>
                </div>
              </article>
            ))}
          </div>
        </Reveal>
        <Divider />
        <Reveal id="gift">
          <Title label="WITH GRATITUDE">마음 전하실 곳</Title>
          <p className="section-intro">
            함께해 주시는 마음만으로도 감사합니다.
            <br />
            보내주신 축복, 소중히 간직하겠습니다.
          </p>
          <Accordion type="multiple" className="accounts">
            {w.accounts.map((accounts, i) => (
              <AccordionItem value={String(i)} key={i}>
                <AccordionTrigger>
                  <span>{i === 0 ? "신랑측" : "신부측"} 계좌번호</span>
                </AccordionTrigger>
                <AccordionContent>
                  {accounts.map((account) => (
                    <div className="account-row" key={account.name}>
                      <div>
                        <span className="account-relation">
                          {account.relation}
                        </span>
                        <strong>{account.name}</strong>
                        <p>
                          {account.bank} <span>{account.number}</span>
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="small"
                        onClick={() =>
                          copy(account.number, "계좌번호를 복사했어요.")
                        }
                        aria-label={`${account.name} 계좌번호 복사`}
                      >
                        <Copy size={13} />
                        복사
                      </Button>
                    </div>
                  ))}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          {w.demo && <p className="helper">테스트용 가상 계좌입니다.</p>}
        </Reveal>
        <Divider />
        <Reveal id="rsvp" className="rsvp-section">
          <div className="rsvp-stamp" aria-hidden="true">
            <Heart size={26} />
            <Star />
          </div>
          <Title label="RSVP">그날, 함께해 주실래요?</Title>
          <p className="section-intro">
            귀한 걸음에 부족함이 없도록 준비하겠습니다.
            <br />
            참석 의사를 미리 알려주시면 감사하겠습니다.
          </p>
          <Button className="full" onClick={() => setRsvpOpen(true)}>
            <Send size={17} />
            참석 의사 전달하기
            <ArrowRight size={17} />
          </Button>
          {localMode && (
            <p className="helper">테스트 입력은 이 브라우저에만 저장됩니다.</p>
          )}
        </Reveal>
        <Divider />
        <Reveal id="guestbook" className="guestbook-section">
          <Title label="LITTLE NOTES OF LOVE">우리에게 남기는 마음</Title>
          <p className="section-intro">
            당신의 한마디가 오래도록 기억될 거예요.
          </p>
          <Button variant="outline" onClick={() => setNoteOpen(true)}>
            <PenLine size={16} />
            축하 메시지 남기기
          </Button>
          <div className="guestbook-meta">
            <span>{notes.length}개의 따뜻한 마음</span>
            <span className="live-state">
              <i />
              {realtimeState}
            </span>
          </div>
          {loadError && (
            <div role="alert" className="error-box">
              {loadError}
              <button
                onClick={() =>
                  loadNotes()
                    .then((v) => {
                      setNotes(v);
                      setLoadError("");
                    })
                    .catch(() => {})
                }
              >
                다시 불러오기
              </button>
            </div>
          )}
          <div className="notes" aria-live="polite" aria-relevant="additions">
            {notes.map((note, i) => (
              <article
                className={`note color-${note.color_index}`}
                style={{
                  transform: `rotate(${[-2, 1.8, -1, 2.4, 0.8, -1.6][i % 6]}deg)`,
                }}
                key={note.id}
              >
                <span className="note-tape" aria-hidden="true" />
                <Heart className="note-heart" size={17} />
                <p>{note.content}</p>
                <footer>
                  <span>FROM.</span>
                  <strong>{note.author}</strong>
                </footer>
              </article>
            ))}
          </div>
          {notes.length === 0 && !loadError && (
            <p className="empty-note">첫 번째 축하 메시지를 남겨 주세요.</p>
          )}
          {localMode && (
            <p className="helper">
              예시 메시지와 이 브라우저에 저장된 메시지입니다.
            </p>
          )}
        </Reveal>
        <Divider />
        <footer className="footer">
          <p className="footer-script">See you on our day.</p>
          <p>우리의 시작에 함께해 주셔서 감사합니다.</p>
          <div className="footer-monogram">
            {w.monogram[0]}
            <Star />
            {w.monogram[1]}
          </div>
          <div className="share-buttons">
            <Button variant="outline" onClick={share}>
              <MessageCircle size={16} />
              카카오톡 공유
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                const url = shareUrl();
                if (url) copy(url, "청첩장 링크를 복사했어요.");
                else notify("웹에 배포한 후 링크를 복사할 수 있어요.");
              }}
            >
              <Copy size={16} />
              링크 복사
            </Button>
          </div>
          <small>
            {year}. {pad(month)}. {pad(day)} · {w.groom.firstName} &{" "}
            {w.bride.firstName}
          </small>
          {w.demo && (
            <p className="demo-disclaimer">
              TEST INVITATION
              <br />
              이름·장소·연락처·계좌는 예시이며, 사진은 AI로 생성했습니다.
            </p>
          )}
        </footer>
      </main>

      <Dialog open={contactOpen} onOpenChange={setContactOpen}>
        <DialogContent className="contact-dialog">
          <span className="eyebrow">WITH LOVE</span>
          <DialogTitle>소중한 마음 전하기</DialogTitle>
          <DialogDescription>
            반가운 연락을 기다리고 있습니다.
          </DialogDescription>
          <div className="contact-columns">
            {w.contacts.map((people, i) => (
              <div key={i}>
                <h3>
                  {i === 0 ? "신랑측" : "신부측"}
                  <Star />
                </h3>
                {people.map((person) => (
                  <article className="person" key={person.name}>
                    <span>{person.relation}</span>
                    <strong>{person.name}</strong>
                    <div>
                      <a
                        className="icon-link"
                        href={`tel:${person.phone.replace(/-/g, "")}`}
                        aria-label={`${person.name} 전화하기`}
                      >
                        <Phone size={17} />
                      </a>
                      <a
                        className="icon-link"
                        href={`sms:${person.phone.replace(/-/g, "")}`}
                        aria-label={`${person.name} 문자하기`}
                      >
                        <MessageCircle size={17} />
                      </a>
                    </div>
                  </article>
                ))}
              </div>
            ))}
          </div>
          {w.demo && (
            <p className="helper">전화번호는 테스트용 010-0000-0000입니다.</p>
          )}
        </DialogContent>
      </Dialog>

      <Dialog
        open={photo !== null}
        onOpenChange={(open) => {
          if (!open) setPhoto(null);
        }}
      >
        <DialogContent className="lightbox">
          <DialogTitle className="sr-only">웨딩 사진 확대</DialogTitle>
          <DialogDescription className="sr-only">
            좌우 화살표로 사진을 넘길 수 있습니다.
          </DialogDescription>
          {photo !== null && (
            <>
              <img src={w.gallery[photo].src} alt={w.gallery[photo].alt} />
              <div className="lightbox-nav">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() =>
                    setPhoto((photo + w.gallery.length - 1) % w.gallery.length)
                  }
                  aria-label="이전 사진"
                >
                  <ArrowLeft />
                </Button>
                <span>
                  {photo + 1} / {w.gallery.length}
                </span>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setPhoto((photo + 1) % w.gallery.length)}
                  aria-label="다음 사진"
                >
                  <ArrowRight />
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={rsvpOpen} onOpenChange={setRsvpOpen}>
        <DialogContent className="rsvp-dialog">
          {sent ? (
            <div className="success-state">
              <span className="success-icon">
                <Check size={30} />
              </span>
              <span className="eyebrow">THANK YOU</span>
              <DialogTitle>
                {localMode
                  ? "테스트 저장이 완료됐어요"
                  : "소중한 응답을 받았습니다"}
              </DialogTitle>
              <DialogDescription>
                {form.name}님,{" "}
                {form.attendance ? `${form.guest_count}명 참석` : "불참"}으로{" "}
                {localMode ? "이 브라우저에 저장했습니다." : "전달했습니다."}
                <br />
                {localMode
                  ? "신랑·신부에게 실제 전송되지는 않습니다."
                  : "마음 전해 주셔서 감사합니다."}
              </DialogDescription>
              <DialogClose asChild>
                <Button className="full">확인</Button>
              </DialogClose>
            </div>
          ) : (
            <>
              <span className="eyebrow">A LITTLE RSVP</span>
              <DialogTitle>함께해 주실 수 있나요?</DialogTitle>
              <DialogDescription>
                소중한 분들을 정성껏 맞이할 수 있도록
                <br />
                참석 의사를 알려 주세요.
              </DialogDescription>
              <form onSubmit={submitRsvp} className="rsvp-form">
                <Choice
                  label="구분"
                  value={form.side}
                  options={[
                    { value: "groom", label: "신랑측" },
                    { value: "bride", label: "신부측" },
                  ]}
                  onChange={(v) =>
                    setForm({ ...form, side: v as Submission["side"] })
                  }
                />
                <label className="field">
                  성함 <span className="required">*</span>
                  <input
                    required
                    maxLength={40}
                    autoComplete="name"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="성함을 입력해 주세요"
                  />
                </label>
                <Choice
                  label="참석 여부"
                  value={form.attendance ? "yes" : "no"}
                  options={[
                    { value: "yes", label: "참석" },
                    { value: "no", label: "불참석" },
                  ]}
                  onChange={(v) =>
                    setForm({ ...form, attendance: v === "yes" })
                  }
                />
                {form.attendance && (
                  <>
                    <label className="field">
                      참석 인원 <span className="required">*</span>
                      <input
                        required
                        type="number"
                        min="1"
                        max="30"
                        inputMode="numeric"
                        value={form.guest_count || ""}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            guest_count: Number(e.target.value),
                          })
                        }
                        placeholder="본인 포함 총 참석인원"
                      />
                      <span className="field-help">
                        본인을 포함한 총 인원을 입력해 주세요.
                      </span>
                    </label>
                    <label className="field">
                      동행인 <span className="optional">선택</span>
                      <input
                        maxLength={150}
                        value={form.companions}
                        onChange={(e) =>
                          setForm({ ...form, companions: e.target.value })
                        }
                        placeholder="함께 오시는 분 성함"
                      />
                    </label>
                    <Choice
                      label="식사 여부"
                      value={form.meal_preference}
                      options={[
                        { value: "yes", label: "예정" },
                        { value: "no", label: "안함" },
                        { value: "undecided", label: "미정" },
                      ]}
                      onChange={(v) =>
                        setForm({
                          ...form,
                          meal_preference: v as Submission["meal_preference"],
                        })
                      }
                    />
                  </>
                )}
                <label className="field">
                  연락처 <span className="optional">선택</span>
                  <input
                    type="tel"
                    autoComplete="tel"
                    maxLength={20}
                    value={form.phone}
                    onChange={(e) =>
                      setForm({ ...form, phone: e.target.value })
                    }
                    placeholder="010-0000-0000"
                  />
                </label>
                <label className="field">
                  전하고 싶은 말 <span className="optional">선택</span>
                  <textarea
                    rows={2}
                    maxLength={500}
                    value={form.message}
                    onChange={(e) =>
                      setForm({ ...form, message: e.target.value })
                    }
                    placeholder="짧은 마음을 남겨 주세요"
                  />
                </label>
                {localMode ? (
                  <p className="form-notice">
                    테스트용입니다. 이 브라우저에만 저장되며 신랑·신부에게
                    전송되지 않습니다.
                  </p>
                ) : (
                  <p className="form-notice">
                    이 사이트는 입력된 응답을 누구나 조회할 수 있도록 설정되어
                    있습니다. 연락처 입력은 선택입니다.
                  </p>
                )}
                {formError && (
                  <p className="error-box" role="alert">
                    {formError}
                  </p>
                )}
                <Button type="submit" className="full" disabled={sending}>
                  <Send size={16} />
                  {sending ? "저장 중…" : "참석 의사 전달하기"}
                </Button>
              </form>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={noteOpen} onOpenChange={setNoteOpen}>
        <DialogContent>
          <span className="eyebrow">LEAVE A LITTLE LOVE</span>
          <DialogTitle>마음을 남겨 주세요</DialogTitle>
          <DialogDescription>
            두 사람에게 오래도록 남을 따뜻한 한마디.
          </DialogDescription>
          <form className="note-form" onSubmit={submitNote}>
            <label className="field">
              이름
              <input
                required
                maxLength={30}
                autoComplete="name"
                value={noteName}
                onChange={(e) => setNoteName(e.target.value)}
                placeholder="보내는 분의 성함"
              />
            </label>
            <label className="field">
              축하 메시지
              <textarea
                required
                rows={5}
                maxLength={500}
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="두 사람의 시작을 축하해 주세요"
              />
              <span className="char-count">{noteContent.length} / 500</span>
            </label>
            <p className="form-notice">
              {localMode
                ? "이 브라우저에만 저장되는 테스트 메시지입니다."
                : "이름과 메시지는 청첩장을 보는 모든 분께 공개됩니다."}
            </p>
            {noteError && (
              <p className="error-box" role="alert">
                {noteError}
              </p>
            )}
            <Button type="submit" disabled={noteSaving} className="full">
              <Heart size={17} />
              {noteSaving ? "저장 중…" : "축하 메시지 남기기"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <div
        className={`toast ${toast ? "show" : ""}`}
        role="status"
        aria-live="polite"
      >
        {toast && (
          <>
            <Check size={16} />
            <span>{toast}</span>
          </>
        )}
      </div>
    </>
  );
}
