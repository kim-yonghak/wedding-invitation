import * as React from "react";
import * as Primitive from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";
export const Accordion = Primitive.Root;
export function AccordionItem(
  props: React.ComponentPropsWithoutRef<typeof Primitive.Item>,
) {
  return <Primitive.Item className="accordion-item" {...props} />;
}
export function AccordionTrigger({
  children,
  ...props
}: React.ComponentPropsWithoutRef<typeof Primitive.Trigger>) {
  return (
    <Primitive.Header>
      <Primitive.Trigger className="accordion-trigger" {...props}>
        {children}
        <ChevronDown size={19} />
      </Primitive.Trigger>
    </Primitive.Header>
  );
}
export function AccordionContent(
  props: React.ComponentPropsWithoutRef<typeof Primitive.Content>,
) {
  return <Primitive.Content className="accordion-content" {...props} />;
}
