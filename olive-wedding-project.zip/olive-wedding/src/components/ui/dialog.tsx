// shadcn/ui Dialog composition: Radix handles focus trap, Escape, aria and focus restoration.
import * as React from "react";
import * as Primitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cn } from "./utils";
export const Dialog = Primitive.Root;
export const DialogTitle = Primitive.Title;
export const DialogDescription = Primitive.Description;
export const DialogClose = Primitive.Close;
export function DialogContent({
  className,
  children,
  ...props
}: React.ComponentPropsWithoutRef<typeof Primitive.Content>) {
  return (
    <Primitive.Portal>
      <Primitive.Overlay className="dialog-overlay" />
      <Primitive.Content className={cn("dialog-content", className)} {...props}>
        <div className="sheet-handle" aria-hidden="true" />
        {children}
        <Primitive.Close className="dialog-close" aria-label="닫기">
          <X size={21} />
        </Primitive.Close>
      </Primitive.Content>
    </Primitive.Portal>
  );
}
