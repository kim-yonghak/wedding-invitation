import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig(({ mode }) => ({
  plugins: [react()],
  base: "./",
  server: { host: "0.0.0.0", port: 5175, strictPort: true },
  build: {
    assetsInlineLimit: mode === "standalone" ? 10_000_000 : 4096,
    cssCodeSplit: false,
    rolldownOptions: { output: { codeSplitting: false } },
  },
}));
