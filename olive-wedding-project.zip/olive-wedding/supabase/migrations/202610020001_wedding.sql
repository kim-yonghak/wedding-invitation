-- Requested public INSERT / SELECT policy. Apply in your Lovable Cloud / Supabase SQL editor.
begin;
create table if not exists public.rsvp_submissions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null check (char_length(btrim(name)) between 1 and 40),
  phone text not null default '' check (char_length(phone) <= 20),
  attendance boolean not null,
  guest_count integer not null check (guest_count between 0 and 30),
  meal_preference text not null check (meal_preference in ('yes','no','undecided')),
  message text not null default '' check (char_length(message) <= 500),
  side text not null check (side in ('groom','bride')),
  companions text not null default '' check (char_length(companions) <= 150),
  check ((attendance and guest_count >= 1) or (not attendance and guest_count = 0 and meal_preference = 'no' and companions = ''))
);
create table if not exists public.guestbook_messages (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  author text not null check (char_length(btrim(author)) between 1 and 30),
  content text not null check (char_length(btrim(content)) between 1 and 500),
  color_index integer not null default floor(random()*6)::integer check (color_index between 0 and 5)
);
create index if not exists guestbook_created_at_idx on public.guestbook_messages (created_at desc);
alter table public.rsvp_submissions enable row level security;
alter table public.guestbook_messages enable row level security;
grant usage on schema public to anon, authenticated;
revoke all on public.rsvp_submissions, public.guestbook_messages from anon, authenticated;
grant select, insert on public.rsvp_submissions, public.guestbook_messages to anon, authenticated;
drop policy if exists rsvp_public_insert on public.rsvp_submissions;
drop policy if exists rsvp_public_select on public.rsvp_submissions;
drop policy if exists guestbook_public_insert on public.guestbook_messages;
drop policy if exists guestbook_public_select on public.guestbook_messages;
create policy rsvp_public_insert on public.rsvp_submissions for insert to anon, authenticated with check (true);
create policy rsvp_public_select on public.rsvp_submissions for select to anon, authenticated using (true);
create policy guestbook_public_insert on public.guestbook_messages for insert to anon, authenticated with check (true);
create policy guestbook_public_select on public.guestbook_messages for select to anon, authenticated using (true);
do $$
begin
 if not exists (select 1 from pg_publication where pubname='supabase_realtime') then
   create publication supabase_realtime;
 end if;
 if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='guestbook_messages') then
   alter publication supabase_realtime add table public.guestbook_messages;
 end if;
end $$;
commit;
