# 우리의 다음, 함께 — 모바일 청첩장

올리브 `#474a37` / 라임 `#d8e592`, Noto Sans KR + Gowun Batang 조합의 한국어 모바일 청첩장입니다. 480px 중앙 정렬이며, 480px보다 작은 화면에서는 100% 너비로 줄어듭니다.

## 바로 테스트

함께 전달한 **wedding-invitation.html**을 내려받아 Chrome 또는 Edge에서 열면 됩니다. 사진, 폰트, JavaScript가 포함되어 별도 설치 없이 화면과 로컬 입력을 테스트할 수 있습니다. 지도 검색 링크에는 인터넷 연결이 필요합니다.

현재 이름, 날짜, 연락처, 계좌, 예식장 및 교통 안내는 모두 테스트 값입니다. 커버 1장, 갤러리 3장, 예식장 안내 3장은 AI 생성 이미지입니다. `src/assets/ASSET_PROMPTS.json`에 이미지 생성 방식과 프롬프트를 기록했습니다.

## 구현된 기능

1. 전체 화면 웨딩 커버, 스크롤 이동과 바운스 표시
2. 초대 글, 양가 부모님과 신랑·신부 이름
3. 양가 2열 연락처 모달, 6인 전화·문자 링크
4. 스와이프 갤러리, 이동 버튼, 확대 모달 및 키보드 좌우 이동
5. 한국 시간 기준 달력, 날짜 강조, D-day 및 실시간 초 단위 카운트다운
6. 테스트 약도, 네이버·카카오 지도 검색, 주소 복사, 교통·주차 안내
7. 사진과 설명을 담은 예식장 안내 카드 3개
8. 신랑측·신부측 계좌 아코디언, 계좌 복사
9. ‘참석 의사 전달하기’ 버튼으로만 여는 RSVP 바텀시트, 입력 검증 (자동 팝업 없음)
10. 6색 포스트잇 방명록, 2열 메이슨리, 길이에 따른 높이 조절
11. 카카오 공유 연결 코드, 모바일 공유 대체 동작, 링크 복사

초대 문구의 `걸음 지키며`는 문맥에 맞게 `곁을 지키며`로 정리했습니다. 이름과 참석/불참 선택을 별도 항목으로 구성했습니다. 입력 내용은 React 텍스트로 렌더링하여 HTML을 실행하지 않습니다.

## 로컬 실행과 수정

Node.js 22.12 이상을 사용합니다.

```bash
npm install
npm run dev
```

기본 포트는 5175입니다. `http://localhost:5175/`로 접속합니다. 개발 서버는 같은 네트워크에서 테스트할 수 있도록 `0.0.0.0`에 바인딩합니다. 실행 환경이 네트워크 인터페이스 조회를 제한하면 `npm run dev -- --host 127.0.0.1`로 실행합니다.

| 바꿀 내용 | 수정 위치 |
| --- | --- |
| 이름·부모님·예식 날짜·예식장·주소·교통·계좌·전화 | `src/config.ts` |
| 영어 이름·이니셜 | `src/config.ts`의 `englishNames`, `monogram` |
| 테스트 표시 제거 | `src/config.ts`의 `demo: false` |
| 커버 | `src/assets/hero.jpg` |
| 갤러리 1·2·3 | `src/assets/gallery-1.jpg` ~ `gallery-3.jpg` |
| 안내 1·2·3 | `src/assets/guide-1.jpg` ~ `guide-3.jpg` |
| 안내 글 | `src/config.ts`의 `guides` |
| 초대 글 | `src/App.tsx`의 `invitation-copy` |
| 컬러·간격·글자 크기 | `src/styles.css` |
| 검색/공유 미리보기 제목·설명 | `index.html`의 title, description, og 태그 |

날짜는 `2027-05-22T14:00:00+09:00`과 같이 한국 시간대 `+09:00`를 포함합니다. 다른 청첩장으로 사용할 때 `id`도 변경하면 이전 로컬 테스트 입력과 구분됩니다.

## 저장 방식과 현재 상태

**실제 Lovable Cloud 프로젝트나 데이터베이스는 생성되지 않았습니다.** 제작 계정에서 Lovable/Supabase 연동이 비활성화되어 있어 연결 가능한 코드와 SQL을 제공합니다.

- 연결 값이 없으면 브라우저 localStorage에 RSVP와 방명록을 저장합니다. 서버 전송이나 다른 기기 공유는 하지 않습니다.
- 같은 출처의 다른 브라우저 탭에는 `storage` 이벤트로 방명록 변경을 반영합니다.
- 클라우드 연결 후에는 예시 방명록 없이 데이터베이스의 메시지를 읽고, `guestbook_messages` INSERT를 Realtime으로 구독합니다. 연결 성공 시 다시 조회하여 연결 중 누락된 메시지를 보완합니다.
- 클라우드 저장 실패를 로컬 저장 성공으로 위장하지 않습니다. 폼을 유지하고 오류를 표시합니다.
- 로컬 테스트 입력은 클라우드 연결 시 자동 업로드되지 않습니다.
- 샘플 방명록은 4개이며 최근 메시지 최대 200개를 표시합니다.

## Lovable Cloud / Supabase 연결

1. 사용 가능한 본인 프로젝트에서 `supabase/migrations/202610020001_wedding.sql`을 실행합니다.
2. `.env.example`을 `.env.local`로 복사한 후 URL과 공개용 publishable/anon key를 입력합니다. 서비스 역할 비밀 키는 넣지 않습니다.
3. 개발 서버를 다시 실행하거나 아래 빌드 명령으로 배포 파일을 만듭니다.

```dotenv
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLIC_KEY
```

테이블:

| 테이블 | 필드 |
| --- | --- |
| rsvp_submissions | id, created_at, name, phone, attendance, guest_count, meal_preference, message, side, companions |
| guestbook_messages | id, created_at, author, content, color_index |

`side`, `companions`는 요청한 구분·동행인 입력을 보존하는 추가 필드입니다. 불참은 인원 0, 식사 no, 동행인 빈 문자열로 저장합니다. 클라이언트가 생성한 UUID를 사용하므로 같은 RSVP 저장 요청을 재시도해도 중복 기본 키로 여러 건 저장되지 않습니다.

요청대로 두 테이블 모두 누구나 INSERT/SELECT할 수 있는 RLS입니다. 이 설정에서는 RSVP의 이름·전화번호도 공개 조회되므로 폼에도 이를 안내합니다. 익명 UPDATE/DELETE 권한은 부여하지 않습니다. Realtime에는 방명록 테이블만 추가합니다. SQL은 신규 프로젝트 기준으로 작성되었으며 실제 프로젝트 실행은 아직 검증하지 않았습니다.

## 카카오 지도와 공유

실제 카카오 지도 임베드는 `demo: false`, JavaScript 키, 실제 좌표가 있을 때 동작합니다. 기본 테스트 상태에서는 자체 약도를 표시하고 네이버·카카오 링크는 서울숲 검색으로 연결됩니다.

카카오디벨로퍼스에서 앱과 웹 도메인을 설정하고 다음 값을 넣습니다.

```dotenv
VITE_KAKAO_JAVASCRIPT_KEY=YOUR_JAVASCRIPT_KEY
VITE_SITE_URL=https://YOUR_PUBLISHED_SITE
VITE_SHARE_IMAGE_URL=https://YOUR_PUBLIC_IMAGE_URL/hero.jpg
```

카카오 지도 API 사용 설정과 공유 웹 도메인 등록도 해당 앱에서 완료합니다. 현재 카카오 JavaScript SDK 2.8.3을 사용합니다. 공유 이미지에는 접근 가능한 HTTPS 이미지 URL이 필요합니다. 실제 앱 키를 사용한 지도·카카오 메시지 전송은 아직 검증하지 않았습니다.

공유 설정 전에는 지원되는 브라우저의 시스템 공유 창을 사용하며, 그 외에는 링크를 복사합니다. 로컬 HTML은 배포 URL 설정 전에는 공유 가능한 URL이 없다는 안내를 표시합니다. 실제 카카오 전송 완료를 성공으로 표시하지 않습니다.

공식 참고 문서: [Supabase Postgres Changes](https://supabase.com/docs/guides/realtime/postgres-changes), [Kakao JavaScript 공유](https://developers.kakao.com/docs/ko/kakaotalk-share/js-link), [Kakao 지도](https://apis.map.kakao.com/web/guide/).

## 빌드

```bash
npm run build
```

생성된 `dist/` 폴더를 정적 웹 호스팅에 올립니다. 실제 사이트 주소 발급/배포는 수행하지 않았습니다. 배포용 빌드는 이미지와 폰트를 별도 파일로 출력하므로 브라우저 캐시와 이미지 지연 로딩을 활용합니다.

```bash
npm run standalone
```

프로젝트 폴더의 바로 상위에 `wedding-invitation.html`을 생성합니다. 단독 파일에는 이미지와 WOFF2 폰트가 모두 포함되므로 배포용 초기 로딩보다 크며, 오프라인 디자인 테스트용으로 적합합니다. `.env.local`의 공개 설정 값은 빌드 시 포함됩니다.

## 기술 구성

React, TypeScript, Vite, Supabase JS, Lucide 아이콘. shadcn/ui의 Button/Dialog/Accordion 구성 방식을 사용하며, Radix UI가 모달 포커스 잠금·Escape 닫기·스크린리더 접근성을 처리합니다. 스타일은 청첩장 팔레트에 맞춘 CSS로 구성했습니다. `components.json`은 구조 참고용이며 이 프로젝트는 Tailwind 빌드 없이 동작합니다.

키보드 포커스 표시, 44px급 주요 터치 영역, 모션 감소 설정, 16px 입력 글자 크기, 바텀시트 내부 스크롤을 지원합니다. 생성 이미지와 테스트 정보는 실제 사진·예식장 정보로 교체해 사용하세요.
