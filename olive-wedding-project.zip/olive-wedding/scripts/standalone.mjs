import fs from "node:fs";
import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
let html = fs.readFileSync(
  path.join(root, "dist-standalone/index.html"),
  "utf8",
);
html = html.replace(
  /<script type="module"[^>]*src="([^"]+)"[^>]*><\/script>/g,
  (_, src) =>
    `<script>${fs.readFileSync(path.join(root, "dist-standalone", src), "utf8").replaceAll("</script", "<\\/script")}</script>`,
);
html = html.replace(
  /<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g,
  (_, src) =>
    `<style>${fs.readFileSync(path.join(root, "dist-standalone", src), "utf8")}</style>`,
);
// Run after the root exists, including when opened directly via file://.
html = html.replace(/<script>[\s\S]*?<\/script>/g, (script) => {
  globalThis.inlineScript = script;
  return "";
});
html = html.replace("</body>", () => `${globalThis.inlineScript || ""}</body>`);
const fontLicenses = ['Gowun-Batang-OFL.txt', 'Noto-Sans-KR-OFL.txt'].map(name => fs.readFileSync(path.join(root, 'licenses', name), 'utf8')).join('\n\n');
html = html.replace('</head>', () => `<!-- Embedded font licenses\n${fontLicenses.replaceAll('--', '—')}\n-->\n</head>`);
fs.writeFileSync(path.join(root, "../wedding-invitation.html"), html);
console.log(
  "Created wedding-invitation.html (self-contained images, fonts and JavaScript)",
);
