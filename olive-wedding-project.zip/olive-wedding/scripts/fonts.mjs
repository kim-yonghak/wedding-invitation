// Keep WOFF2 only. Ship both Korean font families locally, without a CDN request.
import fs from "node:fs";
import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
const css = ["noto-sans-kr", "gowun-batang"]
  .map((pkg) =>
    fs
      .readFileSync(
        path.join(root, "node_modules/@fontsource", pkg, "400.css"),
        "utf8",
      )
      .replace(/, url\([^)]*\.woff\) format\('woff'\)/g, "")
      .replaceAll("./files/", `../node_modules/@fontsource/${pkg}/files/`),
  )
  .join("\n");
fs.writeFileSync(path.join(root, "src/fonts.css"), css);
